#!/usr/bin/env python3
"""One load, several policies: the simulator used for what it was built for.

  python3 -m sim.policies --tag trace2

Takes a scripted load that was actually run on the A100 (governor_trace.py; the same
batches, the same number of layers per segment, the same idle gaps) and runs it under
each policy. The first row is the configuration that was measured, so its error is known
(`sim.validate_trace`); every other row is the same load under a different controller,
kernel or hardware.

  busy s     time the GPU spends in MoE layers: the work is the same in every row, so
             this is how fast the policy did it
  busy J     energy drawn during those layers
  peak W     highest 100 ms board-power reading
  over ms    time the readings spent above the limiter's peak (1.05 x TDP)
  set-points clock changes that reached the chip

Rows marked * use vLLM's per-SM costs for a pinned kernel: a kernel nobody has built.
The domains are fixed at 32 + 76 SMs, as silicon would be. "64 cold experts" keeps the
same experts cold for every batch; "rebalanced" moves experts across the boundary per
batch so the two partitions finish together -- software, and free.
"""
import argparse, csv, os
import numpy as np

from .calib import Calib
from .control import make
from .engine import Engine, Kernel, Shared
from .hardware import Hardware, two_domain
from .validate_trace import load, spec_of
from .workload import build

HERE = os.path.dirname(os.path.abspath(__file__))

POLICIES = [
    ("queue kernel, stock governor (measured)", {}, Kernel("queue", 128), {"type": "governor"}),
    ("queue kernel, tdp_bisection", {}, Kernel("queue", 128), {"type": "tdp_bisection"}),
    ("queue kernel, fixed 1050 MHz", {}, Kernel("queue", 128), {"type": "fixed", "f": 1050}),
    ("pinned*, 64 cold experts, one clock", {}, Kernel("queue", 128, 64, 32),
     {"type": "tdp_bisection"}),
    ("pinned*, 64 cold experts, two domains", dict(two=32), Kernel("queue", 128, 64),
     {"type": "tdp_bisection"}),
    ("pinned*, experts rebalanced per batch, one clock", {}, Kernel("queue", 128, -1, 32),
     {"type": "tdp_bisection"}),
    ("pinned*, rebalanced, two domains, governor", dict(two=32), Kernel("queue", 128, -1),
     {"type": "governor"}),
    ("pinned*, rebalanced, two domains, tdp_bisection", dict(two=32), Kernel("queue", 128, -1),
     {"type": "tdp_bisection"}),
    ("pinned*, rebalanced, two domains, 0.05 ms actuation", dict(two=32, actuation_ms=0.05),
     Kernel("queue", 128, -1), {"type": "tdp_bisection"}),
    ("pinned*, rebalanced, two domains, closed_loop", dict(two=32), Kernel("queue", 128, -1),
     {"type": "closed_loop"}),
    ("pinned, one block per SM, rebalanced, two domains", dict(two=32),
     Kernel("persistent", 128, -1), {"type": "tdp_bisection"}),
]


def run(tag="trace2", run_index=0, model="qwen", cal=None, quiet=False):
    cal = cal or Calib.load()
    seg, _, _ = load(tag, model)
    spec = spec_of(seg[run_index])
    shared, rows = Shared(), []
    for name, hw_kw, kernel, ctl in POLICIES:
        hw_kw = dict(hw_kw)
        two = hw_kw.pop("two", None)
        hw = two_domain(two, **hw_kw) if two else Hardware(**hw_kw)
        e = Engine(hw, cal, kernel, build(spec, model), make(ctl), model=model, shared=shared).run()
        busy = sum(L["ms"] for L in e.layers)
        peak = hw.limiter.k_peak * hw.tdp_w
        rows.append(dict(policy=name, layers=len(e.layers), busy_s=busy / 1e3,
                         busy_j=sum(L["mj"] for L in e.layers) / 1e3,
                         mean_w=sum(L["mj"] for L in e.layers) / busy,
                         peak_w=max(x["p_sensor_w"] for x in e.ticks),
                         over_ms=sum(hw.limiter.period_ms for x in e.ticks if x["p_sensor_w"] > peak),
                         setpoints=sum(1 for x in e.events if x["event"] == "setpoint")))
    if not quiet:
        ref = rows[0]
        print(f"the `{tag}` load: {ref['layers']} MoE layers in "
              f"{sum(1 for s in seg[run_index] if s['load'] != 'idle')} segments")
        print(f"  {'policy':54s} {'busy s':>7} {'vs row 1':>8} {'busy J':>8} {'vs row 1':>8} "
              f"{'mean W':>7} {'peak W':>7} {'over ms':>7} {'set-points':>10}")
        for r in rows:
            print(f"  {r['policy']:54s} {r['busy_s']:>7.2f} {(r['busy_s'] / ref['busy_s'] - 1) * 100:>+7.1f}% "
                  f"{r['busy_j']:>8.0f} {(r['busy_j'] / ref['busy_j'] - 1) * 100:>+7.1f}% "
                  f"{r['mean_w']:>7.1f} {r['peak_w']:>7.1f} {r['over_ms']:>7.0f} {r['setpoints']:>10d}")
    return rows


def check_fixed(tag="trace2", clocks=(1050, 1290), quiet=False):
    """The one policy change that CAN be made on the real chip: the same plan was run
    with the clock locked (governor_trace.py --lock). Compare what a fixed clock did to
    the load's busy time and busy energy, measured, with what the simulator says it
    does. Needs sim/out/trace_<tag>.json and trace_lock<f>.json (sim.validate_trace)."""
    import json
    path = lambda t: os.path.join(HERE, "out", f"trace_{t}.json")
    gov = json.load(open(path(tag)))["runs"][0]["segments"]
    n = {s["seg"]: int(r["layers"]) for s, r in zip(
        gov, [r for r in csv.DictReader(open(os.path.join(
            os.path.dirname(HERE), "data", f"governor_trace_{tag}_segments_qwen.csv")))
            if r["run"] == "0" and r["load"] != "idle"])}
    out = []
    for f in clocks:
        if not os.path.exists(path(f"lock{f}")):
            continue
        lock = {s["seg"]: s for s in json.load(open(path(f"lock{f}")))["runs"][0]["segments"]}
        tot = lambda segs, k: (sum(n[g["seg"]] * segs(g)[k + "_ms"] for g in gov) / 1e3,
                               sum(n[g["seg"]] * segs(g)[k + "_ms"] * segs(g)[k + "_w"]
                                   for g in gov) / 1e6)
        (tg, eg), (tl, el) = tot(lambda g: g, "meas"), tot(lambda g: lock[g["seg"]], "meas")
        (sg, xg), (sl, xl) = tot(lambda g: g, "sim"), tot(lambda g: lock[g["seg"]], "sim")
        out.append(dict(clock=f, meas_time_pct=(tl / tg - 1) * 100, meas_energy_pct=(el / eg - 1) * 100,
                        sim_time_pct=(sl / sg - 1) * 100, sim_energy_pct=(xl / xg - 1) * 100,
                        meas_gov_s=tg, meas_gov_kj=eg, meas_lock_s=tl, meas_lock_kj=el))
        if not quiet:
            print(f"  fixed {f} MHz against the governor, the `{tag}` load: measured time "
                  f"{out[-1]['meas_time_pct']:+.1f}% energy {out[-1]['meas_energy_pct']:+.1f}%  |  "
                  f"simulated time {out[-1]['sim_time_pct']:+.1f}% energy {out[-1]['sim_energy_pct']:+.1f}%")
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="trace2")
    a = ap.parse_args()
    rows = run(a.tag)
    fx = check_fixed(a.tag)
    if fx:
        with open(os.path.join(HERE, "out", f"policies_{a.tag}_fixed.csv"), "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(fx[0].keys()))
            w.writeheader(); w.writerows(fx)
    out = os.path.join(HERE, "out", f"policies_{a.tag}.csv")
    with open(out, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    print(f"wrote {out}")
