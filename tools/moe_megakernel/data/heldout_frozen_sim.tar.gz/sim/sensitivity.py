#!/usr/bin/env python3
"""What a second V/f domain is worth, under every assumption nobody can measure.

  python3 -m sim.sensitivity --cells 32

The A100 has one V/f domain, so four things about a two-domain chip are parameters of
the hardware description rather than facts:

  uncore          which clock the shared logic (L2, crossbar) follows
  uncore_share    how much of the clock-dependent idle power belongs to that logic
  cdc_penalty     what crossing between two clock domains costs an L2 delivery
  cold_regulator  whether the lower rail has its own buck converter or hangs off the
                  higher one through an LDO (then its saving is linear in V, not V^2)

For each setting this compares the SAME pinned kernel with one clock (B3) and with a
clock per domain (B4), so the only thing that differs is the second rail:

  energy   least energy at the layer time B3 reaches at 1290 MHz
  latency  fastest layer under TDP

If the answer changed sign across these rows, the simulator could not say whether the
design works. It does not.
"""
import argparse, copy, csv, os
import numpy as np

from .calib import Calib
from .engine import Kernel, Shared
from .hardware import Hardware, two_domain
from .study import Probe, best, bisected, sweep1, sweep2, refine
from .workload import build

HERE = os.path.dirname(os.path.abspath(__file__))
VARIANTS = [("as shipped", {}, {}),
            ("uncore follows the SLOWER domain", dict(uncore="min"), {}),
            ("uncore follows the cold domain", dict(uncore="cold"), {}),
            ("no idle power in shared logic", {}, dict(uncore_share=0.0)),
            ("half the idle power in shared logic", {}, dict(uncore_share=0.5)),
            ("domain crossing costs 5%", dict(cdc_penalty=0.05), {}),
            ("domain crossing costs 10%", dict(cdc_penalty=0.10), {}),
            ("lower rail through an LDO", dict(cold_regulator="ldo"), {})]


def run(cells=32, ktype="persistent", bm=None, n_cold=64, cold_sms=32, tdp=400.0,
        ref_clock=1290, step=30, f_lo=600, cal=None, quiet=False):
    cal0 = cal or Calib.load()
    bm = bm or (128 if cells == 0 or ktype == "queue" else 64)
    L = build([dict(phase="prefill" if cells == 0 else "decode", cells=cells, layers=[0])])[0].layers[0]
    one = Hardware(tdp_w=tdp)
    fine = [f for f in one.clocks() if f >= 510]
    coarse = [one.snap(f) for f in range(one.f_max, f_lo - 1, -step)]
    rows = []
    for name, hw_kw, pw_kw in VARIANTS:
        cal = copy.deepcopy(cal0)
        for k, v in pw_kw.items():
            setattr(cal.power, k, v)
        sh = Shared()
        p3 = sweep1(Probe(cal, one, Kernel(ktype, bm, n_cold, cold_sms), L, sh), fine)
        hw2 = two_domain(cold_sms, tdp_w=tdp, **hw_kw)
        slo = next(p for p in p3 if p[0][0] == ref_clock)[1]
        p4, add = sweep2(Probe(cal, hw2, Kernel(ktype, bm, n_cold), L, sh), coarse, fine)
        p4.append(bisected(cal, hw2, Kernel(ktype, bm, n_cold), L, sh))
        for target in (None, slo):
            refine(p4, add, hw2, tdp, target, rounds=3)
        e3, e4 = best(p3, tdp, slo), best(p4, tdp, slo)
        l3, l4 = best(p3, tdp), best(p4, tdp)
        rows.append(dict(assumption=name, b3_mj=e3[2], b4_mj=e4[2], b4_f="/".join(map(str, e4[0])),
                         energy_pct=(e4[2] / e3[2] - 1) * 100, b3_ms=l3[1], b4_ms=l4[1],
                         b4_f_tdp="/".join(map(str, l4[0])), latency_pct=(l4[1] / l3[1] - 1) * 100))
    if not quiet:
        print(f"{'prefill' if cells == 0 else 'decode'} {L.pairs // 8} tokens; {n_cold} cold experts "
              f"on a {cold_sms}-SM domain; {ktype} per-SM costs, BM{bm}; TDP {tdp:.0f} W")
        print(f"  {'':36s} | {'energy at B3@' + str(ref_clock) + ' latency':>32} | {'fastest under TDP':>30}")
        print(f"  {'assumption':36s} | {'B3 mJ':>7} {'B4 mJ':>7} {'B4 - B3':>8} {'clocks':>9} | "
              f"{'B3 ms':>7} {'B4 ms':>7} {'B4 - B3':>8} {'clocks':>9}")
        for r in rows:
            print(f"  {r['assumption']:36s} | {r['b3_mj']:>7.1f} {r['b4_mj']:>7.1f} "
                  f"{r['energy_pct']:>+7.2f}% {r['b4_f']:>9} | {r['b3_ms']:>7.4f} {r['b4_ms']:>7.4f} "
                  f"{r['latency_pct']:>+7.2f}% {r['b4_f_tdp']:>9}")
    return rows


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--cells", type=int, default=32)
    ap.add_argument("--kernel", default="persistent", choices=["persistent", "queue"])
    ap.add_argument("--n-cold", type=int, default=64)
    ap.add_argument("--cold-sms", type=int, default=32)
    a = ap.parse_args()
    rows = run(a.cells, a.kernel, n_cold=a.n_cold, cold_sms=a.cold_sms)
    out = os.path.join(HERE, "out", f"sensitivity_cells{a.cells}_{a.kernel}.csv")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    print(f"wrote {out}")
