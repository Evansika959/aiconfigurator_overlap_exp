"""What a batch asks of the hardware, computed from the routing histogram alone.

A MoE layer is two grouped GEMMs. The align step sorts the (token, expert) pairs by
expert and pads each expert's run to a multiple of BLOCK_M, so the layer is a list of
ROW-BLOCKS, each BLOCK_M rows of one expert, and each row-block is cut into N-tiles of
BLOCK_N output columns. Everything the hardware does follows from four counts per
partition, and all four come from the histogram:

  experts   how many experts have at least one pair        -> weights that must leave DRAM
  pairs     real (token, expert) pairs                     -> activations read and written
  mblocks   sum over experts of ceil(pairs_e / BLOCK_M)    -> weight panels streamed to SMs
  rows      mblocks * BLOCK_M (padding included)           -> tensor-core work

`ncu_counters.py` measured the hardware's own counts for 100 kernels; `check()` below
compares. Tensor instructions match to the instruction (one mma is 16x8x16 = 2048 MACs).
DRAM bytes read are the weights of the live experts plus the activations, within 3%.

GEMM 1 is (rows x K) @ (K x 2I), GEMM 2 is (rows x I) @ (I x K): GEMM 1 is exactly 2/3 of
the MACs and of the weight bytes for every partition, so a partition's two GEMMs differ
only by that constant.
"""
from dataclasses import dataclass, asdict
import os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(os.path.dirname(HERE), "data")
MACS_PER_MMA = 2048                     # one tensor-core instruction, m16n8k16


@dataclass(frozen=True)
class Shape:
    """One MoE layer's dimensions. bf16: two bytes per element."""
    name: str
    K: int                  # hidden
    I: int                  # expert intermediate
    E: int                  # experts
    topk: int
    layers: int
    npz: str
    bpe: int = 2

    @property
    def w_bytes(self):                  # weights of one expert, both GEMMs
        return (2 * self.I * self.K + self.K * self.I) * self.bpe

    @property
    def epi_bytes(self):
        """Bytes per (token, expert) pair the epilogue moves: activation reads 2I and
        writes I, the top-k sum reads K and writes K / topk."""
        return (3 * self.I + self.K + self.K / self.topk) * self.bpe

    def gemm(self, g):
        """(output columns N, inner dimension K, weight bytes per expert) of GEMM g."""
        if g == "g1":
            return 2 * self.I, self.K, 2 * self.I * self.K * self.bpe
        return self.K, self.I, self.K * self.I * self.bpe


SHAPES = {
    "qwen": Shape("qwen", K=2048, I=768, E=128, topk=8, layers=48, npz="routing_qwen.npz"),
    "qwen3next": Shape("qwen3next", K=2048, I=512, E=512, topk=10, layers=48,
                       npz="routing_qwen3next.npz"),
    "olmoe": Shape("olmoe", K=2048, I=1024, E=64, topk=8, layers=16,
                   npz="routing_olmoe_sharegpt.npz"),
    "granite": Shape("granite", K=1536, I=512, E=40, topk=8, layers=32,
                     npz="routing_granite.npz"),
}


@dataclass(frozen=True)
class Demand:
    """One partition of one layer. Sizes in bytes, work in MACs; g1 + g2 together."""
    experts: int
    pairs: int
    mblocks: int
    rows: int
    block_m: int
    tiles: int
    macs: float             # tensor-core work
    panel_bytes: float      # weights streamed to the SMs: one full panel per row-block
    act_bytes: float        # activation rows loaded by the SMs, once per N-tile
    dram_min: float         # DRAM bytes if every expert's weights are fetched once
    dram_max: float         # DRAM bytes if no row-block finds its panel in L2
    out_bytes: float        # written back

    @property
    def reuse(self):
        """Share of weight-panel loads that CAN be served from L2: every row-block of
        an expert after its first."""
        return 1.0 - self.experts / self.mblocks if self.mblocks else 0.0

    def scaled(self, k):
        """The same partition with k times the work (k passes, or a fraction left)."""
        d = asdict(self)
        for f in ("macs", "panel_bytes", "act_bytes", "dram_min", "dram_max", "out_bytes"):
            d[f] *= k
        return Demand(**d)

    def __bool__(self):
        return self.mblocks > 0


EMPTY = Demand(0, 0, 0, 0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)


def demand(shape, counts, block_m, block_n=128, experts=None, gemm=None):
    """Demand of the experts in `experts` (index array or bool mask; None = all).

    gemm = None gives both GEMMs together (what the calibration sweeps timed);
    'g1' or 'g2' gives one stage, for the engine's per-stage events."""
    c = np.asarray(counts, dtype=np.int64)
    if experts is not None:
        c = c[np.asarray(experts)]
    c = c[c > 0]
    if c.size == 0:
        return EMPTY
    mb = int(np.sum((c + block_m - 1) // block_m))
    rows, pairs, live = mb * block_m, int(c.sum()), int(c.size)
    tiles = macs = panel = act = act_once = out = w_live = 0.0
    for g in (("g1", "g2") if gemm is None else (gemm,)):
        N, K, wb = shape.gemm(g)
        tn = -(-N // block_n)
        tiles += mb * tn
        macs += float(rows) * N * K
        panel += float(mb) * wb
        act += float(pairs) * K * shape.bpe * tn       # the A rows, once per N-tile
        act_once += float(pairs) * K * shape.bpe       # ... but from DRAM only once
        out += float(pairs) * N * shape.bpe
        w_live += float(live) * wb
    return Demand(experts=live, pairs=pairs, mblocks=mb, rows=rows, block_m=block_m,
                  tiles=int(tiles), macs=macs, panel_bytes=panel, act_bytes=act,
                  dram_min=w_live + act_once, dram_max=panel + act_once, out_bytes=out)


def split(counts, n_cold):
    """The paper's partition rule: the n_cold least-routed experts are 'cold'. Stable
    sort, exactly as the measurement scripts do it, so ties break the same way."""
    order = np.argsort(np.asarray(counts), kind="stable")
    cold = np.zeros(len(counts), dtype=bool)
    cold[order[:n_cold]] = True
    return cold


# ---------------------------------------------------------------- routing ----
_ARR = {}


def _array(shape, prefix):
    """A routing array from the model's npz. NpzFile decompresses on EVERY access, so
    the array is kept: a 3000-batch workload otherwise spends 30 s unzipping."""
    key = (shape.npz, prefix)
    if key not in _ARR:
        Z = np.load(os.path.join(DATA, shape.npz))
        _ARR[key] = Z[[k for k in Z.files if k.startswith(prefix)][0]]
    return _ARR[key]


def prefill_counts(shape, rep=0, layer=0):
    A = _array(shape, "prefill")
    return (A[layer] if A.ndim == 2 else A[rep, layer]).astype(np.int64)


def decode_counts(shape, cells, layer=0, start=0):
    """Pool `cells` real decode (rep, step) routings: 64 tokens each. Decode tokens
    pick their experts independently, so pooling cells is a real batch, not a scaled
    histogram. Trimmed to a whole number of tokens, as decode_wall.decode_inputs does."""
    A = _array(shape, "decode")              # (reps, steps, layers, experts)
    flat = A[:, :, layer, :].reshape(-1, A.shape[-1])
    idx = (start + np.arange(cells)) % len(flat)
    c = flat[idx].sum(axis=0).astype(np.int64)
    c[np.argmax(c)] -= int(c.sum()) % shape.topk
    return c


def counts_for(shape, cells, layer=0, rep=0):
    """cells = 0 is the prefill batch of `rep`; otherwise a pooled decode batch."""
    return prefill_counts(shape, rep, layer) if cells == 0 else decode_counts(shape, cells, layer)


# ------------------------------------------------------------------ check ----
def check(model="qwen"):
    """Compare the decomposition with ncu's counters (data/ncu_counters_<model>.csv)."""
    import csv
    shape = SHAPES[model]
    rows = list(csv.DictReader(open(os.path.join(DATA, f"ncu_counters_{model}.csv"))))
    err = {"tensor": [], "dram": [], "tiles": []}
    for r in rows:
        if r["kernel"] != "persistent":
            continue
        cells, bm, part, g = int(r["cells"]), int(r["block_m"]), r["part"], r["gemm"]
        c = counts_for(shape, cells)
        cold = split(c, 64)
        ex = None if part == "all" else (cold if part == "light" else ~cold)
        d = demand(shape, c, bm, experts=ex, gemm=g)
        assert d.rows == int(r["padded_rows"]), (r, d)
        err["tiles"].append(d.tiles / float(r["tiles"]) - 1)
        err["tensor"].append(d.macs / MACS_PER_MMA
                             / float(r["sm__inst_executed_pipe_tensor_sum"]) - 1)
        err["dram"].append(d.dram_min / float(r["dram__bytes_read_sum"]) - 1)
    for k, v in err.items():
        v = np.array(v) * 100
        print(f"  {k:7s} model vs ncu over {len(v)} kernels: median {np.median(v):+.2f}%, "
              f"worst {v[np.argmax(np.abs(v))]:+.2f}%")
    return err


if __name__ == "__main__":
    check()
