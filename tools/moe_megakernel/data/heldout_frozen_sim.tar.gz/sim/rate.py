"""How fast a partition runs: per-SM service time, slowed by what the SMs share.

THE MODEL

A partition on n SMs walks its tile list with a grid stride, so at any instant its SMs
cover a WINDOW of n consecutive tiles: n / tiles_n row-blocks. For each window, every SM
needs three things, and the window takes as long as their sum:

  weight panels   one expert panel per row-block, delivered by L2      kP * panel bytes
  tensor work     the MACs themselves                                  kR * MACs
  DRAM waits      the first row-block of each expert finds its panel
                  missing; every SM working on that expert in this
                  window waits for it, not only the first              L0 * wait bytes

kP, kR and L0 are per-SM costs and scale (mostly) with 1/clock. Two things are shared
by every SM on the chip, whatever V/f domain it sits in, and both slow down as they
fill up:

  DRAM            rho_D = (all DRAM traffic) / BW_D          waits  x 1 / (1 - rho_D)
  L2 delivery     rho_L = (all L2 traffic) / BW_L            panels x 1 / (1 - rho_L)
                          + xi * rho_D ** q

The second term of rho_L is the coupling that co-running partitions exposed: a partition
that streams from DRAM slows its neighbour's L2 HITS, by more than the neighbour's own
DRAM share explains, and by more the closer DRAM is to full.

A window's own traffic depends on how long it takes, so each window is a one-dimensional
root find. This one mechanism gives both effects the measurements show: a partition
alone saturates as it is given more SMs (its own traffic fills DRAM), and two partitions
side by side slow each other (each sees the other's traffic). `solve_rates` is that
second case: a fixed point in which every partition sees the others' average streams.

WHY WINDOWS AND NOT ONE AVERAGE PER PASS. Congestion is convex. A whole layer on 108 SMs
alternates between windows that are all cold experts -- 108 SMs pulling distinct panels
from DRAM at once -- and windows inside one hot expert that touch DRAM not at all. One
average utilisation for the pass under-predicted those layers by 6-13%; per window the
bias is under 2%.

Units: time ms, sizes MB, work GMAC, rates MB/ms (= GB/s), clocks MHz.
"""
from bisect import bisect_right
from dataclasses import dataclass, field
from math import exp
import numpy as np

from .demand import Shape

TILES_N = 128                   # BLOCK_SIZE_N of every kernel in this study


@dataclass(frozen=True)
class Coef:
    """Per-SM costs at one clock, plus the shared capacities."""
    kP: float       # SM*ms per MB of weight panel delivered
    kR: float       # SM*ms per GMAC
    L0: float       # SM*ms per MB of DRAM wait, DRAM idle
    bw_d: float     # DRAM bandwidth, MB/ms
    bw_l: float     # L2 delivery capacity, MB/ms
    xi: float       # how hard a busy DRAM leans on L2 delivery
    q: float        # ... and how sharply that grows as DRAM fills


@dataclass
class RateParams:
    """Clock dependence of Coef. A cost k(f) = a / f + b: `a` is cycles, `b` is the part
    that does not speed up with the SM clock.

    WHICH CLOCK, once there are two. On today's chip there is one and the question does
    not arise; the fit only says how each term moves with THE clock. With V/f domains:

      kP, kR, L0   the partition's own domain clock: they are per-SM costs.
      bw_l         the UNCORE clock (whatever the hardware description says the shared
                   logic follows): it is the L2's own service rate, and it fitted as
                   proportional to the clock (gamma_l = 1.00).
      xi           the partition's own domain clock. It fitted as proportional to the
                   clock (gamma_x = 1.00) -- which is what a delay that does NOT depend
                   on any clock looks like when it is written, as here, relative to a
                   per-SM cost kP that shrinks as 1/f. A busy DRAM adds a fixed time to
                   each delivery; a slow domain feels it less, in proportion.
      bw_d         no clock: HBM runs on its own."""
    aP: float; bP: float
    aR: float; bR: float
    aL: float; bL: float
    bw_d: float
    bw_l: float                 # at f_ref
    gamma_l: float              # bw_l ~ (uncore clock / f_ref) ** gamma_l
    xi: float                   # at f_ref
    gamma_x: float              # xi   ~ (domain clock / f_ref) ** gamma_x
    q: float
    f_ref: float = 1290.0

    def at(self, f, f_uncore=None):
        fu = f if f_uncore is None else f_uncore
        return Coef(kP=self.aP / f + self.bP, kR=self.aR / f + self.bR,
                    L0=self.aL / f + self.bL, bw_d=self.bw_d,
                    bw_l=self.bw_l * (fu / self.f_ref) ** self.gamma_l,
                    xi=self.xi * (f / self.f_ref) ** self.gamma_x, q=self.q)


@dataclass
class Stage:
    """One GEMM of one partition on n SMs: its windows, grouped by type."""
    n: int
    cnt: np.ndarray             # windows of this type
    panel: np.ndarray           # MB of panels per window
    gmac: np.ndarray
    dram: np.ndarray            # MB that must come from DRAM
    wait: np.ndarray            # MB of DRAM wait, summed over the SMs that wait
    gmac_real: float = 0.0      # GMAC on real (token, expert) pairs; the rest is padding
    tot_panel: float = 0.0
    tot_dram: float = 0.0
    tot_gmac: float = 0.0

    def __post_init__(self):
        self.tot_panel = float(self.cnt @ self.panel)
        self.tot_dram = float(self.cnt @ self.dram)
        self.tot_gmac = float(self.cnt @ self.gmac)

    @property
    def gmac_pad(self):
        """Tensor work on padding rows: it takes as long as real work and, multiplying
        zeros, costs much less energy."""
        return self.tot_gmac - self.gmac_real


class Partition:
    """A set of experts of one layer, as the persistent kernel sees it: row-blocks in
    expert order. `stage(g, n)` cuts it into windows for n SMs."""

    def __init__(self, shape: Shape, counts, block_m, experts=None, block_n=TILES_N):
        c = np.asarray(counts, dtype=np.int64)
        if experts is not None:
            c = c[np.asarray(experts)]
        c = c[c > 0]
        self.shape, self.block_m, self.block_n = shape, block_m, block_n
        self.pairs_e = c.astype(float)
        self.m = ((c + block_m - 1) // block_m).astype(float)     # row-blocks per expert
        self.mblocks = float(self.m.sum())
        self.pairs = float(c.sum())
        self.experts = int(c.size)
        self.rows = self.mblocks * block_m
        self._stages = {}

    def __bool__(self):
        return self.mblocks > 0

    def stage(self, g, n, window=None):
        """`window` is how many tiles are in flight at once. For the persistent kernel
        that is one per SM (the default). vLLM's queue kernel keeps several blocks
        resident on each SM, so its window is wider than its SM count."""
        key = (g, n, window)
        if key not in self._stages:
            self._stages[key] = self._build(g, n, window or n)
        return self._stages[key]

    def _build(self, g, n, window):
        N, K, wb = self.shape.gemm(g)
        wb /= 1e6
        tn = -(-N // self.block_n)
        W = max(1.0, window / tn)                  # row-blocks per window
        nw = int(np.ceil(self.mblocks / W - 1e-9))
        s = np.cumsum(self.m) - self.m             # where each expert starts
        k = np.minimum((s / W).astype(int), nw - 1)
        starts = np.bincount(k, minlength=nw).astype(float)
        # every row-block of the expert inside the window waits for its panel
        mult = np.bincount(k, weights=np.minimum(self.m, W), minlength=nw)
        length = np.full(nw, W)
        length[-1] = self.mblocks - W * (nw - 1)
        act = self.pairs * K * self.shape.bpe / 1e6 / self.mblocks      # per row-block
        cols = np.stack([length * wb,
                         length * self.block_m * N * K / 1e9,
                         starts * wb + length * act,
                         mult * wb + length * act], axis=1)
        u, cnt = np.unique(np.round(cols, 9), axis=0, return_counts=True)
        return Stage(n=n, cnt=cnt.astype(float), panel=u[:, 0], gmac=u[:, 1],
                     dram=u[:, 2], wait=u[:, 3], gmac_real=self.pairs * N * K / 1e9)


_CAP = 1.0 - 1e-6           # a shared resource is never quite full


def window_times(panel, gmac, dram, wait, n, kP, kR, L0, bw_d, bw_l, xi, q,
                 ext_d=0.0, ext_l=0.0, iters=14):
    """ms per window. Every argument broadcasts, so one call can solve the windows of
    one stage (the engine) or of a thousand measurements at different clocks (the fit).

    need(t) is the SM time the window asks for if it takes t; it falls as t grows
    because a slower window streams less. The window takes the t where need(t) = t.
    Newton from below, kept inside a bracket: need(t) - t is convex and decreasing, so
    the iterates climb to the root without overshooting, and the bracket catches the
    few windows where the saturation clip breaks convexity."""
    base_d = ext_d / bw_d
    base_l = ext_l / bw_l

    def h(t):
        ud = dram / (t * bw_d)                       # the window's own utilisation
        ul = panel / (t * bw_l)
        rd_raw = base_d + ud
        rd = np.clip(rd_raw, 1e-12, _CAP)
        rl_raw = base_l + ul + xi * rd ** q
        rl = np.minimum(rl_raw, _CAP)
        need = (kP * panel / (1 - rl) + kR * gmac + L0 * wait / (1 - rd)) / n
        drd = np.where(rd_raw < _CAP, -ud / t, 0.0)
        drl = np.where(rl_raw < _CAP, -ul / t + xi * q * rd ** (q - 1) * drd, 0.0)
        dneed = (kP * panel * drl / (1 - rl) ** 2 + L0 * wait * drd / (1 - rd) ** 2) / n
        return need - t, dneed - 1.0

    z = np.zeros(np.broadcast(panel, n, kP, ext_d, base_l).shape)
    rd0 = np.clip(base_d, 1e-12, _CAP) + z
    rl0 = np.minimum(base_l + xi * rd0 ** q, _CAP)
    # the window with nothing of its own in the shared resources: a lower bound
    lo = (kP * panel / (1 - rl0) + kR * gmac + L0 * wait / (1 - rd0)) / n + 1e-12
    hi = 2.0 * lo
    for _ in range(60):                             # widen until need(hi) < hi
        over = h(hi)[0] > 0
        if not over.any():
            break
        lo = np.where(over, hi, lo)
        hi = np.where(over, 2.0 * hi, hi)
    t = lo.copy()
    for _ in range(iters):
        f, df = h(t)
        lo = np.where(f > 0, t, lo)
        hi = np.where(f > 0, hi, t)
        tn = t - f / df
        bad = ~np.isfinite(tn) | (tn <= lo) | (tn >= hi)
        tn = np.where(bad, 0.5 * (lo + hi), tn)
        if np.all(np.abs(tn - t) <= 1e-10 * tn):
            t = tn
            break
        t = tn
    return t


def stage_time(st: Stage, c: Coef, ext_d=0.0, ext_l=0.0):
    """ms for the stage on its own SMs while the rest of the chip streams ext_d MB/ms
    from DRAM and ext_l MB/ms through L2."""
    return float(st.cnt @ window_times(st.panel, st.gmac, st.dram, st.wait, st.n,
                                       c.kP, c.kR, c.L0, c.bw_d, c.bw_l, c.xi, c.q,
                                       ext_d, ext_l))


# What the rest of the chip can be streaming, as utilisations of DRAM and of L2 delivery.
# Dense where congestion bends the curve.
_UD = [0, .1, .2, .3, .4, .5, .6, .7, .78, .85, .9, .94, .97]
_UL = [0, .04, .08, .14, .22, .32]


class Job:
    """One GEMM stage of one partition on its SMs at one clock.

    `time(ext_d, ext_l)` is how long the whole stage takes while the rest of the chip
    streams ext_d MB/ms from DRAM and ext_l MB/ms through L2. The engine asks that at
    every event and controllers ask it thousands of times, so it is tabulated once per
    (stage, clock) -- one vectorised solve of all 78 grid points -- and interpolated in
    ln T. `exact=True` skips the table; `sim.validate` reports the difference."""

    def __init__(self, st: Stage, c: Coef, exact=False):
        self.st, self.c, self.exact = st, c, exact
        self.t = self.s_d = self.s_l = 0.0
        if not exact:
            ud, ul = np.meshgrid(np.array(_UD), np.array(_UL), indexing="ij")
            t = window_times(st.panel, st.gmac, st.dram, st.wait, st.n, c.kP, c.kR, c.L0,
                             c.bw_d, c.bw_l, c.xi, c.q,
                             (ud * c.bw_d)[..., None], (ul * c.bw_l)[..., None])
            self._ln = np.log(t @ st.cnt).tolist()

    def time(self, ext_d=0.0, ext_l=0.0):
        if self.exact:
            return stage_time(self.st, self.c, ext_d, ext_l)
        i, a = _cell(_UD, ext_d / self.c.bw_d)
        j, b = _cell(_UL, ext_l / self.c.bw_l)
        L = self._ln
        v = ((1 - a) * ((1 - b) * L[i][j] + b * L[i][j + 1])
             + a * ((1 - b) * L[i + 1][j] + b * L[i + 1][j + 1]))
        return exp(v)


def _cell(grid, u):
    """Index of the grid cell holding u, and where in it; clamped to the grid."""
    if u <= grid[0]:
        return 0, 0.0
    if u >= grid[-1]:
        return len(grid) - 2, 1.0
    i = bisect_right(grid, u) - 1
    return i, (u - grid[i]) / (grid[i + 1] - grid[i])


RELAX = 0.65                # each job slows as its neighbour speeds up: under-relax


def solve_rates(jobs, tol=1e-7, max_iter=80):
    """Fixed point: every job sees the others' average streams. Fills t (ms for its
    whole stage under the current conditions), s_d and s_l on each job. One job needs
    no iteration."""
    for j in jobs:
        j.t = j.time()
        j.s_d, j.s_l = j.st.tot_dram / j.t, j.st.tot_panel / j.t
    if len(jobs) < 2:
        return jobs
    for _ in range(max_iter):
        worst = 0.0
        tot_d, tot_l = sum(j.s_d for j in jobs), sum(j.s_l for j in jobs)
        new = []
        for j in jobs:
            t = j.time(tot_d - j.s_d, tot_l - j.s_l)
            worst = max(worst, abs(t / j.t - 1))
            new.append(j.t + RELAX * (t - j.t))
        for j, t in zip(jobs, new):
            j.t = t
            j.s_d, j.s_l = j.st.tot_dram / t, j.st.tot_panel / t
        if worst < tol:
            break
    return jobs
