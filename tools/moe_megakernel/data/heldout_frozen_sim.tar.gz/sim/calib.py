"""The fitted hardware: everything `calibrate.py` learned from the measured CSVs, in one
JSON file that the engine loads. Nothing in here is specific to a workload.
"""
from dataclasses import dataclass, asdict, field
import json, os

from .rate import RateParams
from .power import PowerParams

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT = os.path.join(HERE, "calib", "a100_qwen.json")


@dataclass
class Epilogue:
    """Activation after GEMM 1 and the top-k sum after GEMM 2: two elementwise passes
    over every SM, memory-bound. ms = t0 + pairs * (c0 + c1 / f); half before GEMM 2,
    half after it. Energy above idle: pairs * (j_dram + g(f) * j_sm)."""
    t0: float
    c0: float
    c1: float
    j_dram: float           # mJ per pair that does not scale with voltage
    j_sm: float             # mJ per pair at the voltage floor
    ref_bytes: float = 9216.0   # bytes per pair of the model it was fitted on (Qwen3-30B);
    #                             another model's pairs are scaled by its own bytes per pair

    def ms(self, pairs, f):
        return self.t0 + pairs * (self.c0 + self.c1 / f)


@dataclass
class Calib:
    persistent: RateParams          # one resident block per SM, tiles handed to it
    queue: RateParams               # vLLM's kernel: one block per tile, hardware-scheduled
    queue_window: float             # tiles in flight per SM in the queue kernel
    epilogue: Epilogue
    power: PowerParams
    meta: dict = field(default_factory=dict)

    def rate(self, kernel):
        return self.queue if kernel == "queue" else self.persistent

    def save(self, path=DEFAULT):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        d = dict(persistent=asdict(self.persistent), queue=asdict(self.queue),
                 queue_window=self.queue_window, epilogue=asdict(self.epilogue),
                 power={k: v for k, v in asdict(self.power).items()}, meta=self.meta)
        with open(path, "w") as fh:
            json.dump(d, fh, indent=1)
        return path

    @classmethod
    def load(cls, path=DEFAULT):
        d = json.load(open(path))
        return cls(persistent=RateParams(**d["persistent"]), queue=RateParams(**d["queue"]),
                   queue_window=d["queue_window"], epilogue=Epilogue(**d["epilogue"]),
                   power=PowerParams(**d["power"]), meta=d.get("meta", {}))
