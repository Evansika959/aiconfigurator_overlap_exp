"""Event-driven power and performance simulator for MoE inference on a GPU whose SMs can
be split into V/f domains.

  demand.py     what a batch asks of the hardware, from the routing histogram alone
  hardware.py   the machine: SMs, V/f domains, TDP, limiter, actuation delay
  rate.py       how fast each partition runs: per-SM service time + shared memory
  power.py      board power from activity, not from configuration
  control.py    who sets the clocks: governor, fixed, tdp_bisection, closed loop, ...
  engine.py     the event loop
  calibrate.py  fits rate.py and power.py to the measured CSVs in ../data
  validate.py   replays every measurement through the simulator and reports the error
  run.py        command line: a YAML/JSON scenario in, four tables out

Nothing here touches a GPU. See README.md in this directory.
"""
