#!/usr/bin/env python3
"""Print the tables of ../RESULTS_SIM.md from what is in sim/calib and sim/out.

  python3 -m sim.report            # markdown on stdout

A table in a results document goes stale the moment the data behind it is refitted.
These are generated, pasted, and then guarded by ../check_consistency.py.
"""
import csv, json, os

from .calib import Calib

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")


def _st(s, key):
    x = s.get(key)
    return f"{x['n']} | {x['rms']:.2f}% | {x['bias']:+.2f}% | {x['worst']:+.1f}%" if x else "| | |"


def calibration(cal):
    m, r, p, e = cal.meta, cal.persistent, cal.power, cal.epilogue
    print("| fit | fitted on | free numbers | rms | worst |")
    print("|---|---|---|---|---|")
    a = m["rate"]
    print(f"| rate, persistent kernel | {a['all']['n']} solo and co-run times, "
          f"{a['clocks'][0]}-{a['clocks'][-1]} MHz | {a['free']} | {a['all']['rms']:.2f}% | "
          f"{a['all']['worst']:+.1f}% |")
    q = m["queue"]
    print(f"| rate, queue kernel | {q['all']['n']} end-to-end layer times, 3 campaigns | 4 + window | "
          f"{q['all']['rms']:.2f}% | {q['all']['worst']:+.1f}% |")
    print(f"| epilogue time | {m['epilogue']['n']} (whole layer) - (its launches) | 3 | "
          f"{m['epilogue']['rms']:.2f}% | {m['epilogue']['worst']:+.1f}% |")
    w = m["power"]
    print(f"| board power | {w['all']['n']} solo and co-run records | 4 + 2 per clock | "
          f"{w['all']['rms']:.2f}% of board power | {w['all']['worst']:+.1f}% |")
    print()
    print("| parameter | value | meaning |")
    print("|---|---|---|")
    f = 1290.0
    rows = [("kP at 1290 MHz", f"{(r.aP / f + r.bP) * 1e3:.2f} us SM / MB",
             f"weight-panel delivery per SM; {r.bP / (r.aP / f + r.bP) * 100:.0f}% of it does not scale with the clock"),
            ("kR at 1290 MHz", f"{r.aR / f:.3f} ms SM / GMAC",
             f"tensor work per SM: {2 / (r.aR / f):.2f} TFLOP/s per SM"),
            ("L0 at 1290 MHz", f"{r.aL / f * 1e3:.2f} us SM / MB", "DRAM wait per SM, DRAM idle"),
            ("BW_D", f"{r.bw_d:.0f} GB/s", "DRAM bandwidth"),
            ("BW_L at 1290 MHz", f"{r.bw_l / 1e3:.1f} TB/s", "L2 delivery capacity; proportional to the clock"),
            ("xi at 1290 MHz", f"{r.xi:.3f}", "how hard a busy DRAM leans on L2 delivery"),
            ("e_mac", f"{p.e_mac:.3f} J/TMAC", "tensor work on real pairs, at the voltage floor"),
            ("e_pad", f"{p.e_pad:.3f} J/TMAC", f"tensor work on padding rows: {p.e_pad / p.e_mac * 100:.0f}% of real"),
            ("e_panel", f"{p.e_panel * 1e3:.1f} mJ/GB", "weight panels delivered to SMs, at the floor"),
            ("e_dram", f"{p.e_dram * 1e3:.1f} mJ/GB", "DRAM traffic; the same at every clock"),
            ("g(1050), g(1290), g(1410)",
             ", ".join(f"{p.g_at(x):.3f}" for x in (1050, 1290, 1410)), "supply voltage squared, relative to the floor"),
            ("P_idle(510), (1050), (1290), (1410)",
             ", ".join(f"{p.idle_at(x):.1f}" for x in (510, 1050, 1290, 1410)) + " W", "board, nothing running"),
            ("P_shared", f"{p.p_shared:.1f} W", "the part of idle power no clock changes"),
            ("epilogue", f"{e.t0 * 1e3:.0f} us + pairs x ({e.c0 * 1e6:.2f} + {e.c1 * 1e6:.0f}/f) ns",
             "activation and top-k sum")]
    for a_, b, c in rows:
        print(f"| {a_} | {b} | {c} |")
    for stem, cv in (m.get("cross_validation") or {}).items():
        print(f"\nCross-validation: fitted on the scan alone, the `{stem[9:]}` sweep's {cv['n']} "
              f"times came out at rms {cv['rms']:.2f}%, bias {cv['bias']:+.2f}%, worst {cv['worst']:+.1f}%.")


def ladder():
    v = json.load(open(os.path.join(OUT, "validation.json")))
    print("| rung | what | time: n | rms | bias | worst | power: n | rms | bias | worst |")
    print("|---|---|---|---|---|---|---|---|---|---|")
    for k, x in v.items():
        if isinstance(x, dict) and "label" in x:
            print(f"| {x.get('rung', '')} | {x['label']} | {_st(x, 'time')} | {_st(x, 'power')} |")
    print()
    print("| batch | measured MHz | W | ms | simulated MHz | W | ms |")
    print("|---|---|---|---|---|---|---|")
    for g in v["governor"]:
        print(f"| {g['tokens']} | {g['meas_clock']:.0f} | {g['meas_w']:.1f} | {g['meas_ms']:.4f} | "
              f"{g['sim_clock']:.0f} | {g['sim_w']:.1f} | {g['sim_ms']:.4f} |")
    print()
    print("| trace | segments x runs | latency rms | power rms | clock rms | energy of each run | "
          "first 400 ms after a load step: load change / short idle / wake | highest 100 ms reading, "
          "simulated / measured |")
    print("|---|---|---|---|---|---|---|---|")
    for tag, s in v.get("traces", {}).items():
        tr = s.get("transient_rms_pct", {})
        t3 = " / ".join(f"{tr[k]:.2f}%" if tr.get(k) is not None else "-"
                        for k in ("load change", "short idle", "wake"))
        pk = s.get("peak_reading_w", {})
        print(f"| `{tag}` | {s['segments'] // s['runs']} x {s['runs']} | {s['latency_rms_pct']:.2f}% | "
              f"{s['power_rms_pct']:.2f}% | {s['clock_rms_mhz']:.0f} MHz | "
              + ", ".join(f"{x:+.1f}%" for x in s["energy_err_pct"])
              + f" | {t3} | {pk.get('sim', 0):.0f} / {pk.get('meas', 0):.0f} W |")


def study(stem):
    path = os.path.join(OUT, f"study_{stem}.csv")
    if not os.path.exists(path):
        return
    rows = list(csv.DictReader(open(path)))
    b0 = next(r for r in rows if r["name"] == "B0")
    print(f"**{stem}**\n")
    for obj in dict.fromkeys(r["objective"] for r in rows):
        print(f"*{obj}*\n")
        print("| | configuration | clock MHz | ms | W | mJ | ms vs B0 | mJ vs B0 | best split |")
        print("|---|---|---|---|---|---|---|---|---|")
        for r in rows:
            if r["objective"] != obj:
                continue
            if not r["ms"]:
                print(f"| {r['name']} | {r['what']} | cannot meet it | | | | | | |")
                continue
            ms, mj = float(r["ms"]), float(r["mj"])
            print(f"| {r['name']} | {r['what']} | {r['f']} | {ms:.4f} | {float(r['w']):.1f} | {mj:.1f} | "
                  f"{(ms / float(b0['ms']) - 1) * 100:+.1f}% | {(mj / float(b0['mj']) - 1) * 100:+.1f}% | "
                  f"{r['config']} |")
        print()


def compact(stems=("decode1024", "decode2048", "decode4096", "prefill")):
    """Every control group against B0, one column per workload: time for the first
    objective, energy for the other two."""
    T = {}
    for stem in stems:
        path = os.path.join(OUT, f"study_{stem}.csv")
        if not os.path.exists(path):
            return
        T[stem] = {(r["objective"], r["name"]): r for r in csv.DictReader(open(path))}
    objs = list(dict.fromkeys(k[0] for k in T[stems[0]]))
    names = [n for n in dict.fromkeys(k[1] for k in T[stems[0]]) if n != "B0"]
    print("| objective | | " + " | ".join(stems) + " |")
    print("|---|---|" + "---|" * len(stems))
    for i, obj in enumerate(objs):
        col = "ms" if i == 0 else "mj"
        for n in names:
            cells = []
            for stem in stems:
                r, b0 = T[stem][(obj, n)], T[stem][(obj, "B0")]
                cells.append(f"{(float(r[col]) / float(b0[col]) - 1) * 100:+.1f}%" if r["ms"]
                             else "cannot meet it")
            print(f"| {obj} ({'time' if i == 0 else 'energy'}) | {n} {T[stems[0]][(obj, n)]['what']} | "
                  + " | ".join(cells) + " |")
    print()


def policies(tag="trace2"):
    path = os.path.join(OUT, f"policies_{tag}.csv")
    if not os.path.exists(path):
        return
    rows = list(csv.DictReader(open(path)))
    ref = rows[0]
    print("| policy | busy s | vs row 1 | busy J | vs row 1 | highest 100 ms reading |")
    print("|---|---|---|---|---|---|")
    for i, r in enumerate(rows):
        dt = f"{(float(r['busy_s']) / float(ref['busy_s']) - 1) * 100:+.1f}%" if i else ""
        de = f"{(float(r['busy_j']) / float(ref['busy_j']) - 1) * 100:+.1f}%" if i else ""
        print(f"| {r['policy']} | {float(r['busy_s']):.2f} | {dt} | {float(r['busy_j']):.0f} | {de} | "
              f"{float(r['peak_w']):.0f} W |")
    fx = os.path.join(OUT, f"policies_{tag}_fixed.csv")
    if os.path.exists(fx):
        print()
        for r in csv.DictReader(open(fx)):
            print(f"Fixed {r['clock']} MHz against the governor: measured {float(r['meas_time_pct']):+.1f}% time, "
                  f"{float(r['meas_energy_pct']):+.1f}% energy; simulated {float(r['sim_time_pct']):+.1f}%, "
                  f"{float(r['sim_energy_pct']):+.1f}%.")
    print()


def sensitivity(name):
    path = os.path.join(OUT, name)
    if not os.path.exists(path):
        return
    print("| assumption | energy at B3's 1290 MHz latency: B4 - B3 | clocks | fastest under TDP: B4 - B3 | clocks |")
    print("|---|---|---|---|---|")
    for r in csv.DictReader(open(path)):
        print(f"| {r['assumption']} | {float(r['energy_pct']):+.2f}% | {r['b4_f']} | "
              f"{float(r['latency_pct']):+.2f}% | {r['b4_f_tdp']} |")


def main():
    cal = Calib.load()
    print("## calibration\n"); calibration(cal)
    print("\n## validation\n"); ladder()
    print("\n## control groups\n")
    compact()
    for stem in ("decode1024", "decode2048", "decode4096", "prefill"):
        study(stem)
    print("## policies on a moving load\n")
    policies()
    print("## sensitivity\n")
    for name in ("sensitivity_cells32_persistent.csv", "sensitivity_cells64_queue.csv"):
        print(f"`{name}`\n"); sensitivity(name); print()


if __name__ == "__main__":
    main()
