#!/usr/bin/env python3
"""Replay every measurement through the simulator and report how far off it is.

  python3 -m sim.validate            # prints the ladder, writes sim/out/validation.json

The ladder goes from what the model was fitted on to what it never saw. A rung is only
as good as the rung below it, and the two-domain predictions sit above the top one --
no measurement can reach them on a one-domain chip, which is exactly why every rung
underneath has to be reported and not just the best one.

  0  decomposition     rows, tiles, MACs, DRAM bytes            vs ncu counters
  1  fitted            solo and co-run times and power          the scan (in-sample)
  2  other days        the same model on earlier campaigns      never fitted
  3  other workloads   new batch sizes, tile sizes, cold        never fitted
                       counts, clocks, and another layer
  4  whole layers      end to end through the event engine      partly fitted
  5  the governor      clock, power, latency it settles at      never fitted
  6  a moving load     a scripted trace under the governor,     never fitted
                       on one time axis with the A100
  7  self-consistency  two domains at one clock = one domain; energy = integral of power

Time errors are ln(predicted / measured); power errors are a share of board power.
"""
import argparse, json, os
from collections import defaultdict
import numpy as np

from . import meas
from .calib import Calib
from .control import Fixed, Governor
from .demand import check as check_demand
from .engine import Engine, Kernel, Shared
from .hardware import Hardware, Domain, two_domain
from .rate import Job, solve_rates
from .workload import build

HERE = os.path.dirname(os.path.abspath(__file__))


def launch_gap(f):
    """ms between two kernels of one CUDA-graph replay: from the five configurations
    that both the scan (no gap) and the earlier single-pass sweeps (two gaps per pass)
    measured -- prefill, 16 cold experts, cold partition on 54 SMs, 1050-1410 MHz."""
    return 0.5 * (0.0062 + 37.8 / f)


def _energy(cal, st, f):
    """mJ of dynamic energy to run one stage once, by activity."""
    return cal.power.stage_mj(cal.power.g_at(f), st)


def solo(cal, r, exact=False):
    """(ms per pass, board W) of a partition alone, continuously repeated."""
    c = cal.persistent.at(r["f"])
    t = e = 0.0
    for g in ("g1", "g2"):
        st = r["part"].stage(g, r["n"])
        t += Job(st, c, exact=exact).time()
        e += _energy(cal, st, r["f"])
    pw = cal.power
    gap = 2 * launch_gap(r["f"]) if r.get("replay") else 0.0
    return t + gap, pw.idle_at(r["f"]) + (pw.act_at(r["f"]) * t + e) / (t + gap)


def corun(cal, r, exact=False):
    """Light beside heavy, both repeated so that they overlap: ((ms, ms), board W)."""
    c = cal.persistent.at(r["f"])
    T, P = {"light": 0.0, "heavy": 0.0}, 0.0
    E = {"light": 0.0, "heavy": 0.0}
    for g in ("g1", "g2"):
        jobs = [Job(r[k]["part"].stage(g, r[k]["n"]), c, exact=exact) for k in ("light", "heavy")]
        solve_rates(jobs)
        for k, j in zip(("light", "heavy"), jobs):
            T[k] += j.t
            E[k] += _energy(cal, j.st, r["f"])
    pw = cal.power
    P = pw.idle_at(r["f"]) + pw.act_at(r["f"]) + sum(E[k] / T[k] for k in T)
    return (T["light"], T["heavy"]), P


MIN_REPLAY_MS = 1.0     # replayed single passes shorter than this are mostly launch gap
L2_MB = 40.0            # the A100's L2. A partition whose weights fit in it is measured
#                         by the sweeps as something inference never does: the pass is
#                         repeated, so after the first one nothing comes from DRAM. The
#                         simulator charges DRAM on every pass, as one pass per layer would.


def fits_l2(r):
    """True if a swept record has a partition whose weights stay resident in L2."""
    parts = [r["part"]] if r["kind"] == "solo" else [r["light"]["part"], r["heavy"]["part"]]
    return any(p.experts * p.shape.w_bytes / 1e6 < L2_MB for p in parts)


def layer(cal, cells, bm, f, kernel="persistent", n_cold=0, cold_sms=0, hw=None, n=3,
          shared=None, layer_index=0, launch_ms=0.02, model="qwen"):
    """(ms, W) of one whole layer end to end, steady state, through the event engine."""
    b = build([dict(phase="prefill" if cells == 0 else "decode", cells=cells,
                    layers=[layer_index], repeat=n)], model)
    hw = hw or Hardware()
    e = Engine(hw, cal, Kernel(kernel, bm, n_cold, cold_sms, launch_ms), b,
               Fixed(f), model=model, shared=shared, record=False, limiter=False).run()
    L = e.layers[-1]
    return L["ms"], L["w"]


def stats(e):
    e = np.asarray(e, float)
    if not len(e):
        return None
    return dict(n=int(len(e)), rms=round(float(np.sqrt(np.mean(e ** 2))), 2),
                bias=round(float(e.mean()), 2),
                worst=round(float(e[np.argmax(np.abs(e))]), 1))


RUNG = [""]


def row(label, t, p, out, key):
    st, sp = stats(t), stats(p)
    out[key] = dict(rung=RUNG[0], label=label, time=st, power=sp)
    f = lambda s: (f"{s['n']:5d} {s['rms']:6.2f} {s['bias']:+6.2f} {s['worst']:+7.1f}"
                   if s else f"{'':>5} {'':>6} {'':>6} {'':>7}")
    print(f"  {label:44s} | {f(st)} | {f(sp)}")


POINTS = []             # (rung, group, quantity, measured, simulated) for the figure


def part_records(cal, recs, out, key, label, rung="fitted"):
    te, pe = [], []
    for r in recs:
        if r.get("replay") and r["ms"] < MIN_REPLAY_MS:
            continue
        if r["kind"] == "solo":
            t, p = solo(cal, r)
            te.append(np.log(t / r["ms"]) * 100)
            pe.append((p - r["power"]) / r["power"] * 100)
            POINTS.append((rung, key, "ms", r["ms"], t))
            POINTS.append((rung, key, "w", r["power"], p))
        elif r["kind"] == "corun":
            (tl, th), p = corun(cal, r)
            te += [np.log(tl / r["light"]["ms"]) * 100, np.log(th / r["heavy"]["ms"]) * 100]
            pe.append((p - r["power"]) / r["power"] * 100)
            POINTS.append((rung, key, "ms", r["light"]["ms"], tl))
            POINTS.append((rung, key, "ms", r["heavy"]["ms"], th))
            POINTS.append((rung, key, "w", r["power"], p))
    row(label, te, pe, out, key)
    return te, pe


def run(model="qwen", cal=None, quiet=False):
    cal = cal or Calib.load()
    out = {}
    POINTS.clear()
    print("0  decomposition vs ncu")
    check_demand(model)

    hdr = f"  {'':44s} | {'time: n':>5} {'rms%':>6} {'bias%':>6} {'worst%':>7} | " \
          f"{'power: n':>5} {'rms%':>6} {'bias%':>6} {'worst%':>7}"
    RUNG[0] = "1 fitted"
    print("\n1  fitted: the training sweeps, 16-108 SMs"); print(hdr)
    scan = meas.train(model)
    for stem, _ in meas.TRAIN:
        sub = [r for r in scan if r["src"] == stem]
        if sub:
            cl = sorted({r["f"] for r in sub})
            part_records(cal, [r for r in sub if r["kind"] == "solo"], out, stem + "_solo",
                         f"{stem[9:]}, {cl[0]}-{cl[-1]} MHz: solo")
            part_records(cal, [r for r in sub if r["kind"] == "corun"], out, stem + "_corun",
                         f"{stem[9:]}, {cl[0]}-{cl[-1]} MHz: co-run")
    for stem, cv in (cal.meta.get("cross_validation") or {}).items():
        print(f"  ({stem[9:]}, scored BEFORE it was fitted, by a fit on the scan alone: time rms "
              f"{cv['rms']:.2f}%, bias {cv['bias']:+.2f}%, worst {cv['worst']:+.1f}%, n={cv['n']})")

    RUNG[0] = "2 other days"
    print("\n2  other days (never fitted; replayed single passes of 1 ms or longer)"); print(hdr)
    old = [("partition_kappa_qwen.csv", 0, 16, "prefill, BM16-128, 54 SMs, 600-1290 MHz"),
           ("partition_kappa_qwen_decode1024.csv", 16, 64, "decode 1024, BM16-128, 600-1290 MHz"),
           ("partition_kappa_qwen_decode2048.csv", 32, 64, "decode 2048, BM16-128, 600-1290 MHz"),
           ("partition_kappa_L8.csv", 0, 8, "prefill, 8 cold experts"),
           ("partition_kappa_L32.csv", 0, 32, "prefill, 32 cold experts"),
           ("partition_kappa_L64.csv", 0, 64, "prefill, 64 cold experts"),
           ("partition_kappa_L96.csv", 0, 96, "prefill, 96 cold experts"),
           ("partition_kappa_qwen_hiclk54.csv", 0, 16, "prefill, 54 SMs, 1050-1410 MHz")]
    for name, cells, nc, label in old:
        if os.path.exists(os.path.join(meas.DATA, name)):
            try:
                part_records(cal, meas.kappa(model, name, cells, nc), out, name[:-4], label,
                             "other days")
            except (ValueError, KeyError) as ex:
                print(f"  {label:44s} | skipped: {ex}")
    first = meas.corun_first(model)
    part_records(cal, [r for r in first if r["kind"] == "solo"], out, "first_solo",
                 "first co-run campaign: solo", "other days")
    part_records(cal, [r for r in first if r["kind"] == "corun"], out, "first_corun",
                 "first co-run campaign: 54+54, 32+76", "other days")

    RUNG[0] = "3 other workloads"
    print("\n3  other workloads (never fitted)"); print(hdr)
    pin_shared = Shared()
    import glob, re
    other = sorted(glob.glob(os.path.join(meas.DATA, f"sm_corun_holdout_L*_{model}.csv")),
                   key=lambda p: int(re.search(r"_L(\d+)_", p).group(1)))
    for path in other:
        name = os.path.basename(path)
        lay = int(re.search(r"_L(\d+)_", name).group(1))
        label = f"MoE layer {lay}"
        h = meas.scan(model, name, layer=lay)
        for r in h:
            r["layer"] = lay
        part_records(cal, [r for r in h if r["kind"] == "solo"], out, name[:-4] + "_solo",
                     label + ": solo", "new workloads")
        part_records(cal, [r for r in h if r["kind"] == "corun"], out, name[:-4] + "_corun",
                     label + ": co-run", "new workloads")
        out[name[:-4] + "_records"] = h
    name = os.path.join(meas.DATA, f"pinned_layer_{model}.csv")
    if os.path.exists(name):
        te, pe = [], []
        for r in meas.pinned(model):
            t, p = layer(cal, r["cells"], r["bm"], r["f"], "persistent", r["n_cold"],
                         r["sm_light"], shared=pin_shared)
            te.append(np.log(t / r["ms"]) * 100); pe.append((p - r["power"]) / r["power"] * 100)
            POINTS.append(("new workloads", "pinned_layer", "ms", r["ms"], t))
            POINTS.append(("new workloads", "pinned_layer", "w", r["power"], p))
        row("pinned layer END TO END, six SM splits", te, pe, out, "pinned_layer")
    else:
        print(f"  {'pinned layer END TO END':44s} | not collected yet")

    RUNG[0] = "3b other models"
    print("\n3b other MODELS: fitted on Qwen3-30B-A3B only, kernel config borrowed from it")
    print(hdr)
    xm = {}
    for m, desc in (("olmoe", "OLMoE, 64 experts, I=1024"), ("granite", "Granite, 40 experts, K=1536"),
                    ("qwen3next", "Qwen3-Next, 512 experts, top-10")):
        name = f"sm_corun_xmodel_{m}.csv"
        if not os.path.exists(os.path.join(meas.DATA, name)):
            continue
        h = meas.scan(m, name)
        res = [r for r in h if r["kind"] in ("solo", "corun") and fits_l2(r)]
        part_records(cal, [r for r in h if r["kind"] == "solo" and not fits_l2(r)], out,
                     f"xmodel_{m}_solo", f"{desc}: solo", "other models")
        part_records(cal, [r for r in h if r["kind"] == "corun" and not fits_l2(r)], out,
                     f"xmodel_{m}_corun", f"{desc}: co-run", "other models")
        if res:
            part_records(cal, res, out, f"xmodel_{m}_l2_resident",
                         f"{desc}: a partition that fits in L2", "other models, L2-resident")
        te, pe, shm = [], [], Shared()
        for r in h:
            if r["kind"] in ("full", "queue"):
                kern = "queue" if r["kind"] == "queue" else "persistent"
                t, p = layer(cal, r["cells"], r["bm"], r["f"], kern, shared=shm, model=m)
                te.append(np.log(t / r["ms"]) * 100); pe.append((p - r["power"]) / r["power"] * 100)
                POINTS.append(("other models", f"xmodel_{m}", "ms", r["ms"], t))
                POINTS.append(("other models", f"xmodel_{m}", "w", r["power"], p))
        row(f"{desc}: whole layers, both kernels", te, pe, out, f"xmodel_{m}_layers")
        xm[m] = True
    if not xm:
        print(f"  {'(no data/sm_corun_xmodel_*.csv)':44s} |")

    RUNG[0] = "4 whole layers"
    print("\n4  whole layers through the event engine, fixed clock"); print(hdr)
    sh = Shared()
    groups = defaultdict(lambda: ([], []))
    allrec = list(scan)
    for k in list(out):
        if k.endswith("_records"):
            allrec += out.pop(k)
    for r in allrec:
        if r["kind"] not in ("full", "queue"):
            continue
        heldout = "layer" in r                           # the layer-24 sweep
        kern = "queue" if r["kind"] == "queue" else "persistent"
        t, p = layer(cal, r["cells"], r["bm"], r["f"], kern, shared=sh,
                     layer_index=r.get("layer", 0))
        key = (kern, "other layers (never fitted)" if heldout else "training sweeps")
        groups[key][0].append(np.log(t / r["ms"]) * 100)
        groups[key][1].append((p - r["power"]) / r["power"] * 100)
        POINTS.append(("whole layers", f"layer_{kern}", "ms", r["ms"], t))
        POINTS.append(("whole layers", f"layer_{kern}", "w", r["power"], p))
    for (kern, src), (te, pe) in sorted(groups.items()):
        row(f"{kern} kernel, {src}", te, pe, out, f"layer_{kern}_{src.replace(' ', '_')}")
    te, pe = [], []
    for r in meas.queue_sweeps(model):
        t, p = layer(cal, r["cells"], 128, r["f"], "queue", shared=sh)
        te.append(np.log(t / r["ms"]) * 100); pe.append((p - r["power"]) / r["power"] * 100)
        POINTS.append(("whole layers", "layer_queue_sweeps", "ms", r["ms"], t))
        POINTS.append(("whole layers", "layer_queue_sweeps", "w", r["power"], p))
    row("queue kernel, 64-7744 tokens, 510-1410 MHz", te, pe, out, "layer_queue_sweeps")
    te, pe = [], []
    for g in meas.governor(model):
        if g["mode"] == "lock1290" and g["held"]:
            t, p = layer(cal, g["cells"], 128, 1290, "queue", shared=sh)
            te.append(np.log(t / g["ms"]) * 100); pe.append((p - g["power"]) / g["power"] * 100)
    row("queue kernel, 512-12288 tokens, 1290 MHz", te, pe, out, "layer_queue_big")
    if os.path.exists(os.path.join(meas.DATA, f"occupancy_{model}.csv")):
        for kern, label in (("persistent", "persistent, BM64 and BM128, 512-7744 tokens"),
                            ("queue", "queue kernel, 512-7744 tokens")):
            te, pe = [], []
            for r in meas.occupancy(model):
                if r["kernel"] != kern or r["blocks"] > 1:
                    continue
                t, p = layer(cal, r["cells"], r["bm"], r["f"], kern, shared=sh)
                te.append(np.log(t / r["ms"]) * 100); pe.append((p - r["power"]) / r["power"] * 100)
                POINTS.append(("whole layers", "occupancy_" + kern, "ms", r["ms"], t))
                POINTS.append(("whole layers", "occupancy_" + kern, "w", r["power"], p))
            row(label + " (never fitted)", te, pe, out, "layer_occupancy_" + kern)
    pv = meas.pin_vs_queue(model)
    te, pe = [], []
    for case, kern in (("queue", "queue"), ("persistent_1blk_per_sm", "persistent")):
        t, p = layer(cal, 0, 128, 1200, kern, shared=sh)
        te.append(np.log(t / pv[case][0]) * 100); pe.append((p - pv[case][1]) / pv[case][1] * 100)
    row("prefill at 1200 MHz, both kernels (Sep 17)", te, pe, out, "layer_pin_vs_queue")

    print("\n5  the stock governor: where it settles (queue kernel, never fitted)")
    print(f"  {'batch':>6} | {'measured':>26} | {'simulated':>26} | {'d clock':>7} {'d W':>6} {'d ms':>6}")
    gov = []
    for g in meas.governor(model):
        if g["mode"] != "governor":
            continue
        b = build([dict(phase="decode", cells=g["cells"], layers=[0],
                        repeat=int(6000 / g["ms"]))])
        e = Engine(Hardware(), cal, Kernel("queue", 128), b, Governor(), shared=sh).run()
        tail = [x for x in e.layers if x["t_start"] > e.t - 3000]
        ms = float(np.mean([x["ms"] for x in tail]))
        w = sum(x["mj"] for x in tail) / sum(x["ms"] for x in tail)
        seg = [(b_ - a, f[0]) for a, b_, _, f, _ in e.trace if a > e.t - 3000]
        clk = sum(d * f for d, f in seg) / sum(d for d, _ in seg)
        gov.append(dict(tokens=g["tokens"], meas_clock=g["clock"], meas_w=g["power"],
                        meas_ms=g["ms"], sim_clock=round(clk, 1), sim_w=round(w, 1),
                        sim_ms=round(ms, 4)))
        print(f"  {g['tokens']:>6} | {g['clock']:>6.0f} MHz {g['power']:>6.1f} W {g['ms']:>7.4f} ms | "
              f"{clk:>6.0f} MHz {w:>6.1f} W {ms:>7.4f} ms | {clk - g['clock']:>+7.0f} "
              f"{w - g['power']:>+6.1f} {(ms / g['ms'] - 1) * 100:>+5.1f}%")
    out["governor"] = gov

    print("\n6  a load that moves, under the governor (python3 -m sim.validate_trace)")
    tr = {}
    for tag in ("dynamics", "trace", "trace2", "forward", "forward2", "lock1050", "lock1290"):
        path = os.path.join(HERE, "out", f"trace_{tag}.json")
        if os.path.exists(path):
            s_ = json.load(open(path))["summary"]
            tr[tag] = s_
            print(f"  {tag:9s} {s_['segments']:3d} segments, {s_['runs']} runs: latency rms "
                  f"{s_['latency_rms_pct']:.2f}%, power rms {s_['power_rms_pct']:.2f}%, clock rms "
                  f"{s_['clock_rms_mhz']:.0f} MHz, energy of each run "
                  + " ".join(f"{x:+.1f}%" for x in s_["energy_err_pct"]))
    out["traces"] = tr

    print("\n7  self-consistency")
    cons = {}
    # (a) two V/f domains at one clock must equal one domain with pinned partitions
    worst = 0.0
    for cells, bm, nc, split in ((32, 64, 64, 32), (16, 16, 64, 48), (0, 128, 16, 16)):
        for f in (930, 1290, 1410):
            a = layer(cal, cells, bm, f, "persistent", nc, split, shared=Shared())
            b_ = layer(cal, cells, bm, [f, f], "persistent", nc, hw=two_domain(split),
                       shared=Shared())
            worst = max(worst, abs(a[0] / b_[0] - 1), abs(a[1] / b_[1] - 1))
    cons["two_domains_same_clock_vs_one_domain"] = worst
    print(f"  two domains at one clock vs one domain, pinned: worst relative difference "
          f"{worst:.1e} (9 cases, time and power)")
    # (b) energy is the integral of the trace
    b = build([dict(phase="decode", cells=32, layers=[0], repeat=200)])
    e = Engine(two_domain(32), cal, Kernel("persistent", 64, 64), b, Fixed([1050, 1290])).run()
    integ = sum((t1 - t0) * p for t0, t1, p, *_ in e.trace)
    lay = sum(x["mj"] for x in e.layers)
    cons["energy_trace_vs_total"] = abs(integ / e.energy - 1)
    cons["energy_layers_vs_total"] = abs(lay / e.energy - 1)
    print(f"  energy: trace integral vs total {abs(integ / e.energy - 1):.1e}, "
          f"sum of layers vs total {abs(lay / e.energy - 1):.1e}")
    # (c) the tabulated job times against the exact window solve
    d = []
    for r in [x for x in scan if x["kind"] == "corun"][::7]:
        a, _ = corun(cal, r); b_, _ = corun(cal, r, exact=True)
        d += [a[0] / b_[0] - 1, a[1] / b_[1] - 1]
    cons["table_vs_exact_rms"] = float(np.sqrt(np.mean(np.square(d))))
    cons["table_vs_exact_worst"] = float(np.max(np.abs(d)))
    print(f"  tabulated vs exact solve, {len(d)} co-run times: rms "
          f"{cons['table_vs_exact_rms'] * 100:.2f}%, worst {cons['table_vs_exact_worst'] * 100:.2f}%")
    out["consistency"] = cons
    ok = worst < 1e-9 and cons["energy_trace_vs_total"] < 1e-9
    print("  PASS" if ok else "  FAIL")

    os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
    with open(os.path.join(HERE, "out", "validation.json"), "w") as fh:
        json.dump(out, fh, indent=1, default=str)
    import csv
    with open(os.path.join(HERE, "out", "validation_points.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["rung", "group", "quantity", "measured", "simulated"])
        w.writerows([(a, b, c, round(m, 6), round(v, 6)) for a, b, c, m, v in POINTS])
    print(f"\nwrote {os.path.join(HERE, 'out', 'validation.json')}")
    return out, ok


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="qwen")
    a = ap.parse_args()
    _, ok = run(a.model)
    raise SystemExit(0 if ok else 1)
